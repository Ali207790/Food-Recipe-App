package com.example.foodrecipebook;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView mRecyclerView;
    List<FoodData> myFoodList;
    FoodData mFoodData;

    private DatabaseReference databaseReference;
    private ValueEventListener eventListener;
    ProgressDialog progressDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.blacky)));

    mRecyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(MainActivity.this, 1);
        mRecyclerView.setLayoutManager(gridLayoutManager);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading items.....");

        myFoodList = new ArrayList<>();

       // mFoodData = new FoodData("Zinger Burger",
              //  "Prepare your chicken breasts by slicing them if they are too large. Then marinate the chicken breasts with the pepper, salt, mustard or all spice powder, and Worcestershire sauce. Leave the chicken over night or at least 4 hours.\n" +
               // "To prepare the batter, beat together an egg and 2 tablespoons of water, then set this aside.\n" +
             //   "Place the marinated chicken breasts in flour and coat generously. Dip them in to the egg and then in to the breadcrumbs, until well coated.\n" +
               // "Deep fry the coated chicken breasts in hot oil on a medium to high heat, untilwell coated.\n" +
              //  "Deep fry the coated chicken breasts in hot oil on a medium to high heat, until the breasts are golden brown and crispy.\n" +
              //  "Slice the buns in half and lightly toast, then stack the final burger, with the lettuce at the\n" +
             //   " top, then the chicken and finally the mayonnaise or KFC zinger sauce. Add sliced American cheese if you fancy a cheesy zinger.", "Rs. 250", R.drawable.zinger);

    //    myFoodList.add(mFoodData);


      //  mFoodData = new FoodData("Lemon-Tarragon Chicken With Rice",
        //        "Step 1\n" +
          //      "In a large saucepan, melt the butter over medium-high heat. When it foams, add the pasta and cook, stirring occasionally, until browned, 3 to 4 minutes. Add the rice and stir until coated, about 1 minute; season with salt and pepper. Add the stock. Bring to a boil. Cover and reduce heat to low. Cook until the rice is almost tender, about 10 minutes. Stir in the asparagus. Cover and cook until the rice and asparagus are tender, 4 to 5 minutes more. Remove from heat. Add the lemon zest and juice. Fluff the rice with a fork.\n" +
            //    "\n" +
              //  "Step 2\n" +
                //"Meanwhile, season the chicken with salt and pepper. In a large skillet, heat the oil, two turns of the pan, over medium-high. Add the chicken and cook, turning occasionally, until golden and cooked through, about 8 minutes. Transfer to a plate and cover with foil to keep warm.\n" +
               // "\n" +
                //"Add the butter to the skillet. When it foams, add the shallots and garlic. Cook, stirring often, until the shallots soften, about 2 minutes. Add the wine; cook, swirling the pan often, until slightly reduced, about 5 minutes. Add the stock. Reduce heat to a simmer. Stir in the crème fraîche, tarragon, lemon zest and juice, and Dijon; season. Add the chicken and spoon some of the sauce on top. Simmer at a very low bubble until the chicken is warm.\n" +
               // "\n" +
              //  "Step 4\n" +
              //  "Divide the rice among plates or shallow bowls. Using tongs, transfer the chicken to a cutting board. Using a sharp knife, slice each chicken breast on an angle and fan on top of the rice. Spoon the remaining sauce on top.", "Rs. 500", R.drawable.image);

//        myFoodList.add(mFoodData);
//
  //      mFoodData = new FoodData("Bread Slices", "Chop the 2 cup roasted chicken, mix with 1/4 tsp salt, 3/4 tsp pepper, 3/4 tsp mustard powder, 1/2 cup mayonnaise and 2 tbsp ketchup.\n" +
    //            "Slightly toast 8 bread slices, apply mayonnaise and put prepared chicken mixture. Cover with second slice of bread.\n" +
      //          "\n" +
        //        "Now put one salad leaves, cucumber slices, tomato slices and a piece of omelets, cover with last 3rd slice of bread.\n" +
          //      "Cut into 4 triangular pieces, fix with tooth picks and serve with fires and Coleslaw salad.\n" +
            //    "Method for Roast ChickenMarinate 2 chicken breasts with 2 tbsp national Tandori Masala, ½ tsp ginger garlic paste and 2 tbsp lemon juice.\n" +
              //  "Cook marinated chicken in pan with 2 tbsp oil and 1/2 cup of water till tender.\n" +
             //   "Take off from flame and shred the chicken","Rs. 150",R.drawable.image2);
     //   myFoodList.add(mFoodData);

      //  mFoodData = new FoodData("Chicken Fried Noodles",
        //        "Boil ½ packet egg noodles and then fry with oil.\n" +
          //      "Remove and keep aside.\n" +
            //    "Cut ½ kg chicken into strips, marinate with 2 tbsp corn flour, salt to taste, 1 tsp crushed black pepper and half beaten egg.\n" +
              //  "Mix well and deep fry till golden brown.\n" +
            //    "Heat 2 tbsp oil in a pan, add 4 – 5 cloves of chopped garlic and fry well.\n" +
             //   "Now add 2 tbsp lemon juice, 4 tbsp chili sauce, 1 chopped carrot, 1 chopped capsicum, 2 chopped spring onion, 2 tbsp brown sugar and fried chicken.\n" +
             //   "Cook well. Spread on top of boiled noodles and serve.\n" +
             //   " ","Rs. 400",R.drawable.image3);
      //  myFoodList.add(mFoodData);

     //   mFoodData = new FoodData("Shawarma",
       //         "Make chicken: In a large bowl, whisk together oil, lemon juice, garlic, and seasonings. Add chicken and toss to coat. Cover and refrigerate for at least 2 hours and up to overnight. \n" +
         //       "Preheat oven to 425° and grease a large baking sheet with cooking spray. Add onion to marinade and toss to coat. Remove chicken and onion from marinade and place on prepared baking sheet. Bake until chicken is golden and cooked through, 30 minutes. Let chicken rest on cutting board for 5 minutes, then thinly slice. \n" +
           //     "\n" +
             //   "Meanwhile, make yogurt sauce: In a small bowl, whisk together yogurt, lemon juice, oil, and garlic. Season with salt and a pinch of red pepper flakes. To serve as a pita, top warmed pitas with chicken, onion, romaine, tomatoes, cucumber, and yogurt sauce.","Rs. 160",R.drawable.image4);
      //  myFoodList.add(mFoodData);
      //  mFoodData = new FoodData("PopCorn Chicken",
        //        "Start by cutting up the chicken fillets into small popcorn sized bites.\n" +
          //      "Soak each chicken piece in the egg for a few minutes.\n" +
            //    "Whilst the chicken is soaking, in a small container add a pinch of pepper, a pinch of salt, paprika, garlic powder, onion powder and the corn flour.\n" +
              //  "\n" +
            //    "Remove the chicken pieces from the egg mixture and leave on a paper towel for a couple of minutes to drain off any excess mixture.\n" +
             //   "Then roll each popcorn chicken bite in the mixture of herbs, spices and flour. Coat each portion well on all sides.\n" +
               // "Lift each piece of chicken directly from the herb mixture and roll in breadcrumbs.\n" +
        //        "Set each piece aside for a few minutes while you heat the oil. This will allow the bread to stick to the chicken well.\n" +
          //      "\n" +
            //    "To cook we prefer a small-ish table top fryer to allow for an even cook on all sides. Ensure the oil is around 350°F (175°C).\n" +
              //  "Drop in a few pieces of popcorn chicken into the fryer and heat until golden brown on all sides. Turn regularly! We fry each piece for 4-5 minutes to ensure the chicken is cooked through.\n" +
          //      "Remove each batch from the fryer and allow to cool on a couple of sheets of paper, before enjoying!","Rs. 500",R.drawable.image5);

      //  myFoodList.add(mFoodData);

      //  mFoodData = new FoodData("Crispy Fry Chicken","Meat (Boneless) 1/2 kg 2 Salt to taste 3 White chilli powder 1 teaspoon 4 flour 3 tablespoons 5 green onions (chop) 1/2 cup 6 garlic, ginger paste 1 teaspoon 7 eggs 1 piece 8 chips (coarsely chopped)  2 cups 9 oils as required\n" +
        //        "\n" +
          //      "Step by Step Instructions\n" +
            //    "\n" +
            //    " 1 In a bowl, mix salt, white chilli powder, flour, green onion, garlic, ginger paste and egg well and add meat and keep for 1/2 hour. 2. Heat oil on medium heat.  Fry crispy and serve hot.","Rs. 500",R.drawable.image6);
    //    myFoodList.add(mFoodData);
     //   mFoodData = new FoodData("Veg Pizza","Price of 1 kg 2 lasagna strips (boiled) 350 g 3 crushed garlic ginger 1 tbsp 4 tomatoes (finely chopped) 4 tbsp 5 onions (finely chopped) 2 tbsp 6 mushrooms (finely chopped) 4000 gm 7 eggplants (chopped)  4 tablespoons 8 tomatoes (crushed) 350 grams 9 tomato ketchup a small bottle 10 soy sauce white vinegar 2 \"2 tablespoons 11 sugar a teaspoon 12 cheddar cheese mozzarella cheese (kaduksh) 4 cups 13 celery 1 tablespoon 14 chopped red pepper 2 tablespoons  Tablespoons 15 salt to taste 16 tablespoons of oil for frying 3 tablespoons of sauce, ingredients: 1 kg of fresh milk 2 kg of flour (sifted) 4 tablespoons of butter 3 tablespoons of butter 4 tablespoons of salt to taste","Rs. 1500",R.drawable.image7);
      //  myFoodList.add(mFoodData);
     //   mFoodData = new FoodData("Beef Lasagna","1 Roast red chillies and celery 2 Heat butter in a pan and fry flour to cool. 3 Then add milk and cook till thick. 4 Mix salt in it and turn off the stove.  Soften 71/2 vinegar and cook for 2 minutes. Remove 8 tablespoons oil in a separate pan. 2 tablespoons oil minced ketchup garlic ginger soy sauce remaining vinegar sugar and salt fry 9 in baking dish  Apply 1/2 layer. 10 Remove the lasagna from the first preheated oven at 180c for 1/2 hour.","Rs. 700",R.drawable.image8);
//        myFoodList.add(mFoodData);
  //      mFoodData = new FoodData("Chicken Pasta","Heat oil in a saucepan, add garlic, ginger paste and fry. When it becomes light golden, add meat and fry it.  Add the required amount of water and cook on medium heat till the meat is melted. 3 When the meat is melted and the water is dry, add spaghetti, add soy sauce and mix. Add pasta sauce in it. Mix well and cook for 1 minute.  Start hot.","Rs. 250",R.drawable.image9);
    //    myFoodList.add(mFoodData);

                 MyAdapter myAdapter = new MyAdapter(MainActivity.this, myFoodList);
                 mRecyclerView.setAdapter(myAdapter);


                 databaseReference = FirebaseDatabase.getInstance().getReference("Recipe");
                 progressDialog.show();
                 eventListener = databaseReference.addValueEventListener(new ValueEventListener() {
                     @Override
                     public void onDataChange(@NonNull DataSnapshot snapshot) {

                         myFoodList.clear();

                         for (DataSnapshot itemSnapshot: snapshot.getChildren()){

                             FoodData foodData = itemSnapshot.getValue(FoodData.class);
                             myFoodList.add(foodData);
                         }
                         myAdapter.notifyDataSetChanged();
                         progressDialog.dismiss();
                     }

                     @Override
                     public void onCancelled(@NonNull DatabaseError error) {

                         progressDialog.dismiss();

                     }
                 });




    }

    public void btn_uploadActivity(View view) {

        startActivity(new Intent(this,UploadRecipe.class));


    }
}