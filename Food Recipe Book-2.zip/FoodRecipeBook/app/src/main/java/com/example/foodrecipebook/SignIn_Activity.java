package com.example.foodrecipebook;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;


public class SignIn_Activity extends AppCompatActivity {


    EditText FullName, PhoneNo, Email, Password;
    TextView newaccount;
    Button SignIn;
    // FirebaseAuth fAuth;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);


        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        //getWindow().setFlags(
            //    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
              //  WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
      //  );


    //    getSupportActionBar().setTitle("Sign In");
      //  getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        newaccount = findViewById(R.id.newaccount);
        SignIn = findViewById(R.id.SignIn);

        FullName = findViewById(R.id.FullName);
        PhoneNo = findViewById(R.id.PhoneNo);
        Email = findViewById(R.id.Email);
        Password = findViewById(R.id.Password);


    //    fAuth = FirebaseAuth.getInstance();

        newaccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { //Toast.makeText(SignIn_Activity.this, "Sign_In", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(SignIn_Activity.this, SignUp_Activity.class);
                startActivity(intent);
            }

        });


       SignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                  //    String email = Email.getText().toString().trim();
                  //  String password = Password.getText().toString().trim();
//
                 // if (TextUtils.isEmpty(email))
               //   if (!email.matches(email))
              //    {
             ///       Email.setError("Email is Required.");
             //      return;
            //    }
            //    if (TextUtils.isEmpty(password))
             //    {
             //      Password.setError("Password is Required.");
             //    return;
              //   }
              //  if (password.length() < 8)
              //  {
              //   Password.setError("Password Must be greater than or equal to 8 characters");
             //   return;
             //    }

              //  fAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
              //  @Override
              //    public void onComplete(@NonNull Task<AuthResult> task) {
              //   if (task.isSuccessful()){
               // Toast.makeText(SignIn_Activity.this, "LoggedIn Successfully", Toast.LENGTH_LONG).show();
               Intent intent = new Intent(SignIn_Activity.this, MainActivity.class);
               startActivity(intent);
             //   }else{
              //     Toast.makeText(SignIn_Activity.this, "Error!" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();

                //    }
                 }

                });



       // SignIn.setOnClickListener(new View.OnClickListener() {
          //  @Override
          //  public void onClick(View v) { //Toast.makeText(SignIn_Activity.this, "Sign_In", Toast.LENGTH_LONG).show();
            //    Intent intent = new Intent(SignIn_Activity.this, MainActivity.class);
            //    startActivity(intent);
          //  }

       // });


          //  }});
    }}